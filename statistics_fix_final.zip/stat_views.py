"""
linkedin_statistics/stat_views.py
Overview + Timeline + Timeline-Detail (AJAX)
"""
from datetime import date, timedelta
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db import connection
from django.http import JsonResponse
import json


def _defaults():
    return (date.today() - timedelta(days=365)).isoformat(), date.today().isoformat()


def _safe(cur, sql, params=None):
    try:
        cur.execute(sql, params or [])
        return cur.fetchall()
    except Exception:
        return None


def _period_fmt(group_by):
    gb = (group_by or 'month').lower()
    if gb == 'day':   return '%%Y-%%m-%%d'
    if gb == 'week':  return '%%x-W%%v'
    return '%%Y-%%m'


def _agg_label(group_by):
    return {'day': 'tagesweise', 'week': 'wochenweise', 'month': 'monatsweise'}.get(
        (group_by or 'month').lower(), 'monatsweise')


def _current_kpis():
    kpi = {
        'followers': 0, 'followers_date': None,
        'posts': 0, 'posts_date': None,
        'impressions': 0, 'engagement': 0, 'metrics_date': None,
    }
    with connection.cursor() as c:
        rows = _safe(c, "SELECT followers_total, date FROM linkedin_followers ORDER BY date DESC LIMIT 1")
        if rows and rows[0][0]:
            kpi['followers'] = rows[0][0]
            kpi['followers_date'] = rows[0][1]

        rows = _safe(c, "SELECT COUNT(*), MAX(COALESCE(pp.post_date, lp.post_date)) FROM linkedin_posts lp LEFT JOIN linkedin_posts_posted pp ON lp.post_id = pp.post_id")
        if rows:
            kpi['posts'] = rows[0][0] or 0
            kpi['posts_date'] = rows[0][1]

        rows = _safe(c, """
            SELECT COALESCE(SUM(imp),0), COALESCE(SUM(eng),0), MAX(md)
            FROM (
                SELECT m.impressions AS imp,
                       (m.likes + m.comments + m.direct_shares) AS eng,
                       m.metric_date AS md
                FROM linkedin_posts_metrics m
                WHERE m.metric_date = (
                    SELECT MAX(m2.metric_date) FROM linkedin_posts_metrics m2
                    WHERE m2.post_id = m.post_id
                )
                GROUP BY m.post_id
            ) sub
        """)
        if rows and rows[0][0]:
            kpi['impressions'] = rows[0][0]
            kpi['engagement'] = rows[0][1]
            kpi['metrics_date'] = rows[0][2]
    return kpi


def _chart_data(d_from, d_to, group_by):
    fmt = _period_fmt(group_by)
    result = {'labels': [], 'impressions': [], 'engagement_rate': [],
              'clicks': [], 'reactions': [], 'comments': [], 'shares': []}
    with connection.cursor() as c:
        rows = _safe(c, """
            SELECT period_key,
                   COALESCE(SUM(impressions),0),
                   COALESCE(SUM(clicks),0),
                   COALESCE(SUM(likes),0),
                   COALESCE(SUM(comments),0),
                   COALESCE(SUM(direct_shares),0),
                   COALESCE(AVG(engagement_rate)*100, 0)
            FROM (
                SELECT DATE_FORMAT(m.metric_date, '""" + fmt + """') AS period_key,
                       m.post_id, m.impressions, m.clicks, m.likes,
                       m.comments, m.direct_shares, m.engagement_rate
                FROM linkedin_posts_metrics m
                WHERE m.metric_date BETWEEN %s AND %s
                  AND m.metric_date = (
                      SELECT MAX(m2.metric_date) FROM linkedin_posts_metrics m2
                      WHERE m2.post_id = m.post_id
                        AND m2.metric_date BETWEEN %s AND %s
                        AND DATE_FORMAT(m2.metric_date, '""" + fmt + """') = DATE_FORMAT(m.metric_date, '""" + fmt + """')
                  )
            ) sub
            GROUP BY period_key ORDER BY period_key
        """, [d_from, d_to, d_from, d_to])
        if rows:
            result['labels']          = [r[0] for r in rows]
            result['impressions']     = [int(r[1] or 0) for r in rows]
            result['clicks']          = [int(r[2] or 0) for r in rows]
            result['reactions']       = [int(r[3] or 0) for r in rows]
            result['comments']        = [int(r[4] or 0) for r in rows]
            result['shares']          = [int(r[5] or 0) for r in rows]
            result['engagement_rate'] = [round(float(r[6] or 0), 2) for r in rows]
    return result


def _top5(order_col):
    with connection.cursor() as c:
        rows = _safe(c, """
            SELECT lp.post_id,
                   COALESCE(lp.post_title, lp.post_id),
                   COALESCE(pp.post_date, lp.post_date),
                   lp.post_url,
                   m.impressions, m.likes, m.comments, m.direct_shares, m.clicks,
                   (m.likes + m.comments + m.direct_shares) AS engagement
            FROM linkedin_posts lp
            LEFT JOIN linkedin_posts_posted pp ON lp.post_id = pp.post_id
            INNER JOIN linkedin_posts_metrics m ON lp.post_id = m.post_id
            WHERE m.metric_date = (
                SELECT MAX(m2.metric_date) FROM linkedin_posts_metrics m2
                WHERE m2.post_id = m.post_id
            )
            ORDER BY """ + order_col + """ DESC LIMIT 5
        """)
        if not rows:
            return []
        return [{'title': r[1], 'post_date': r[2], 'link': r[3] or '',
                 'impressions': r[4] or 0, 'likes': r[5] or 0, 'comments': r[6] or 0,
                 'shares': r[7] or 0, 'clicks': r[8] or 0, 'engagement': r[9] or 0}
                for r in rows]


@login_required
def overview(request):
    df, dt = _defaults()
    d_from   = request.GET.get('from', df)
    d_to     = request.GET.get('to', dt)
    group_by = request.GET.get('group_by', 'month')

    kpi    = _current_kpis()
    charts = _chart_data(d_from, d_to, group_by)
    top5_imp = _top5('m.impressions')
    top5_eng = _top5('engagement')

    return render(request, 'linkedin_statistics/stat_overview.html', {
        'kpi': kpi,
        'top5_imp': top5_imp,
        'top5_eng': top5_eng,
        'date_from': d_from, 'date_to': d_to,
        'tab': 'overview', 'group_by': group_by,
        'agg_text': _agg_label(group_by),
        'labels_json':          json.dumps(charts['labels']),
        'impressions_json':     json.dumps(charts['impressions']),
        'engagement_rate_json': json.dumps(charts['engagement_rate']),
        'clicks_json':          json.dumps(charts['clicks']),
        'reactions_json':       json.dumps(charts['reactions']),
        'comments_json':        json.dumps(charts['comments']),
        'shares_json':          json.dumps(charts['shares']),
    })


@login_required
def timeline(request):
    posts      = []
    top5_json  = '[]'
    max_days   = 30

    with connection.cursor() as c:
        rows = _safe(c, """
            SELECT lp.post_id,
                   COALESCE(lp.post_title, lp.post_id),
                   COALESCE(pp.post_date, lp.post_date),
                   lp.post_url, lp.content_type,
                   COALESCE(m.impressions,0),
                   COALESCE(m.likes,0),
                   COALESCE(m.comments,0),
                   COALESCE(m.direct_shares,0),
                   COALESCE(m.clicks,0)
            FROM linkedin_posts lp
            LEFT JOIN linkedin_posts_posted pp ON lp.post_id = pp.post_id
            LEFT JOIN linkedin_posts_metrics m ON lp.post_id = m.post_id
                AND m.metric_date = (
                    SELECT MAX(m2.metric_date) FROM linkedin_posts_metrics m2
                    WHERE m2.post_id = m.post_id
                )
            ORDER BY COALESCE(pp.post_date, lp.post_date) DESC
        """)
        if rows:
            posts = [{'post_id': r[0], 'title': r[1], 'post_date': r[2],
                      'link': r[3] or '', 'content_type': r[4] or '',
                      'impressions': r[5], 'likes': r[6], 'comments': r[7],
                      'shares': r[8], 'clicks': r[9],
                      'engagement': (r[6] or 0)+(r[7] or 0)+(r[8] or 0)}
                     for r in rows]

        # Top-5-Chart-Daten
        top5_posts = [p for p in posts if p.get('post_date')][:5]
        top5_data  = []
        for tp in top5_posts:
            mrows = _safe(c, """
                SELECT DATEDIFF(m.metric_date, COALESCE(pp.post_date, lp.post_date)) + 1 AS tag,
                       m.impressions
                FROM linkedin_posts_metrics m
                JOIN linkedin_posts lp ON lp.post_id = m.post_id
                LEFT JOIN linkedin_posts_posted pp ON lp.post_id = pp.post_id
                WHERE m.post_id = %s ORDER BY m.metric_date ASC
            """, [tp['post_id']])
            if mrows:
                days = [int(r[0]) for r in mrows if r[0] and r[0] >= 1]
                imps = [int(r[1] or 0) for r in mrows if r[0] and r[0] >= 1]
                if days:
                    max_days = max(max_days, max(days))
                    top5_data.append({'title': (tp['title'] or tp['post_id'])[:40],
                                      'days': days, 'impressions': imps})
        top5_json = json.dumps(top5_data)

    return render(request, 'linkedin_statistics/stat_timeline.html', {
        'posts': posts, 'all_posts': posts, 'tab': 'timeline',
        'top5_json': top5_json, 'max_days': max_days,
    })


@login_required
def timeline_detail(request, post_id):
    """AJAX: Tagesverlauf für einen einzelnen Post."""
    with connection.cursor() as c:
        rows = _safe(c, """
            SELECT DATEDIFF(m.metric_date, COALESCE(pp.post_date, lp.post_date)) + 1 AS tag,
                   m.impressions, m.clicks, m.likes, m.comments, m.direct_shares,
                   m.engagement_rate
            FROM linkedin_posts_metrics m
            JOIN linkedin_posts lp ON lp.post_id = m.post_id
            LEFT JOIN linkedin_posts_posted pp ON lp.post_id = pp.post_id
            WHERE m.post_id = %s ORDER BY m.metric_date ASC
        """, [post_id])

    if not rows:
        return JsonResponse({'daily': []})

    daily = [{'tag': int(r[0]), 'impressions': int(r[1] or 0), 'clicks': int(r[2] or 0),
               'likes': int(r[3] or 0), 'comments': int(r[4] or 0), 'shares': int(r[5] or 0),
               'engagement_rate': round(float(r[6] or 0) * 100, 2)}
             for r in rows if r[0] and r[0] >= 1]

    return JsonResponse({'daily': daily})
